package week07_3;

public interface ExPlayer extends Player{
	public abstract void slow();
}
