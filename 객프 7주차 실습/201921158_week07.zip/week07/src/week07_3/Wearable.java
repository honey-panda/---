package week07_3;

public interface Wearable {
	public abstract void putOn();
	public abstract void putOff();
}
