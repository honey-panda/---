package week07_3;

public interface Player {
	public abstract void play();
	public abstract void stop();
}
