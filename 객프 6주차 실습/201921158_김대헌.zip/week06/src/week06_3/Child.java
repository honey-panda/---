package week06_3;

public class Child extends Parent {
}
