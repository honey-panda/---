package week06_1;

public class Child extends Parent{
	private String childName;
	
	public Child(String name, String childName) {
		super(name);
		this.childName = childName;
	}
	
	@Override
	public void print() {
		System.out.println("�ڽ� Ŭ������ print() �޼ҵ�");
		System.out.println("�ڽ� �̸�: "+ childName);
	}
	
	public void print_parent() {
		super.print();
	}
}
