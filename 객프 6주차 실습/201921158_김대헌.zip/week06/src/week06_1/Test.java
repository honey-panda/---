package week06_1;

public class Test {
	public static void main(String[] args) {
		Child child = new Child("Mary", "Bob");
		child.print();
		child.print_parent();
	}
}
