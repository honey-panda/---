package week06_2;

public class Rectangle extends Shape{
	private int width, height;
	
	@Override
	public void draw() {
		System.out.println("Rectangle draw");
	}
}
