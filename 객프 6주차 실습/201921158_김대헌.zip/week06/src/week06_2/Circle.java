package week06_2;

public class Circle extends Shape{
	private int radius;
	
	@Override
	public void draw() {
		System.out.println("Circle draw");
	}
}
