package week06_2;

public class Shape {
	protected int x,y;
	
	public void draw() {
		System.out.println("Shape draw");
	}
}
