package kimdaeheon_assignment;

public class Silver_Member extends Member {
	private double discountRate; // ������
	
	public Silver_Member(String clientName, String contact, int purchaseNum, double discountRate) {
		super(clientName, contact, purchaseNum); // MemberŬ���� �����ڿ� ���� ����
		this.discountRate = discountRate; // Silver�� ������
	}
	
	public double getDiscountRate() {
		return discountRate; // discountRate getter
	}
	
	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate; // discountRate setter
	}
	
	@Override
	public double calcSales() {
		return 1000 * purchaseNum * discountRate;
	}
}
